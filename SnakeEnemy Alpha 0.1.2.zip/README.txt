README.txt
Make sure to read the README.txt to understand the game:
I am a 11 year old programmer so please dont be upset if somethings not working just try to send a nicely made message then i will se if i can fix it.

How to navigate the player:
W = UP
S = DOWN
D = RIGHT
A = LEFT
--------------------------------------------------------------------------------------------------------------------------------------------------------

IF THE ENEMYS IS NOT SPAWNING TRY TO RESTART THE GAME THE REASON THAT THEY ARE NOT SPAWNING IS THEY SPAWN OUT OF THE WINDOW AND CANT GET BACK
--------------------------------------------------------------------------------------------------------------------------------------------------------

PRATICAL KEYS:
ESC/ESCAPE = CLOSE GAME
--------------------------------------------------------------------------------------------------------------------------------------------------------

THANKS FOR READING THE README.txt
--------------------------------------------------------------------------------------------------------------------------------------------------------

